package com.test.bean;

import javax.validation.constraints.Size;


public class EmployeeBean {
	
	private int employeeId;
	
	@Size(min=2,max=5,message="Name should contain min 2 & max 5 chars")
	private String employeeName;
	
	
	
	public EmployeeBean() {
		super();
	}
	
	
	public EmployeeBean(int employeeId, String employeeName) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
	}


	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	
}
