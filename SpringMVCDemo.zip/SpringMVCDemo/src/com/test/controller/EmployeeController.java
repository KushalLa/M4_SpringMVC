package com.test.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.test.bean.EmployeeBean;

@Controller
public class EmployeeController {

	@RequestMapping("/show")
	public String showHomePage()
	{
		return("index");
	}
	
	@RequestMapping(value="addEmployee",method=RequestMethod.POST)
	//1. public ModelAndView addEmployee(@RequestParam("employeeId") int empId,@RequestParam("employeeName") String empName)
	//2. public ModelAndView addEmployee(@ModelAttribute("emp") EmployeeBean bean)
	public String addEmployee(@ModelAttribute("emp") EmployeeBean bean,BindingResult result,Model model)
	
	{
//		 2.ModelAndView model=new ModelAndView();
		
		/*1.EmployeeBean bean = new EmployeeBean();
		 bean.setEmployeeId(empId);
		 bean.setEmployeeName(empName);*/
		
//		 2.model.setViewName("success");
//		 2.model.addObject("emp", bean);
		 
//		 2.return(model);
		
		if(result.hasErrors())
		{
			model.addAttribute("message", result);
			return("error");
		}
		return("success");
	}
	
		@RequestMapping("/viewAll")
		public ModelAndView viewAllEmployees()
		{
			List<EmployeeBean> list = new ArrayList<EmployeeBean>();
			EmployeeBean e1 = new EmployeeBean(1001,"Kushal");
			EmployeeBean e2 = new EmployeeBean(1002,"Avijit");
			EmployeeBean e3 = new EmployeeBean(1003,"Sagar");
			
			list.add(e1);
			list.add(e2);
			list.add(e3);
			
			ModelAndView model = new ModelAndView();
			model.setViewName("viewAll");
			model.addObject("list", list);
			
			return(model);
		}
	
}
